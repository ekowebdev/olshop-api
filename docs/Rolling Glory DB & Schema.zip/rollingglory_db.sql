-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: db
-- Generation Time: Jul 16, 2023 at 01:38 PM
-- Server version: 8.0.33
-- PHP Version: 8.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rollingglory_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `item_gifts`
--

CREATE TABLE `item_gifts` (
  `id` bigint UNSIGNED NOT NULL,
  `item_gift_code` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_gift_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_gift_description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `item_gift_point` double(10,2) NOT NULL,
  `item_gift_quantity` int NOT NULL,
  `item_gift_status` enum('A','O') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'A' COMMENT 'A = Available, O = Out of Stock',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `item_gifts`
--

INSERT INTO `item_gifts` (`id`, `item_gift_code`, `item_gift_name`, `item_gift_description`, `item_gift_point`, `item_gift_quantity`, `item_gift_status`, `created_at`, `updated_at`) VALUES
(1, '284Pd3n8n56RcwK', 'Samsung Galaxy S9 - Midnight Black 4/64 GB', 'Ukuran layar: 6.2 inci, Dual Edge Super AMOLED 2960 x 1440 (Quad HD+) 529 ppi, 18.5:9 Memori: RAM 6 GB (LPDDR4), ROM 64 GB, MicroSD up to 400GB Sistem operasi: Android 8.0 (Oreo) CPU: Exynos 9810 Octa-core (2.7GHz Quad + 1.7GHz Quad), 64 bit, 10nm processor Kamera: Super Speed Dual Pixel, 12 MP OIS (F1.5/F2.4 Dual Aperture) + 12MP OIS (F2.4) with LED flash, depan 8 MP, f/1.7, autofocus, 1440p@30fps, dual video call, Auto HDR SIM: Dual SIM (Nano-SIM) Baterai: Non-removable Li-Ion 3500 mAh , Fast Charging on wired and wireless', 200000.00, 30, 'A', '2023-07-16 20:37:06', '2023-07-16 20:37:06'),
(2, '3c0oRPe1SM7PpSg', 'iPhone 12 Pro - Pacific Blue 6/128 GB', 'Ukuran layar: 6.1 inci, Super Retina XDR OLED, 2532 x 1170 piksel, 460 ppi, Memori: RAM 6 GB, ROM 128 GB, Sistem operasi: iOS 14, CPU: Apple A14 Bionic Hexa-core (2x3.1 GHz Firestorm + 4x1.8 GHz Icestorm), Kamera: Triple kamera 12 MP (Wide, Ultra Wide, Telefoto) dengan fitur Night mode, Deep Fusion, dan Dolby Vision HDR recording, kamera depan 12 MP dengan fitur Night mode dan Deep Fusion, SIM: Nano-SIM dan eSIM, Baterai: Non-removable Li-Ion 2815 mAh, Fast Charging, Wireless Charging', 500000.00, 15, 'A', '2023-07-16 20:37:07', '2023-07-16 20:37:07'),
(3, 'zaiU8ILKP9ZGT3x', 'Xiaomi Redmi Note 10 Pro - Dark Night 8/128 GB', 'Ukuran layar: 6.67 inci, Super AMOLED, 1080 x 2400 piksel, 395 ppi, Memori: RAM 8 GB, ROM 128 GB, MicroSD up to 512GB (shared SIM slot), Sistem operasi: Android 11, MIUI 12, CPU: Qualcomm Snapdragon 732G Octa-core (2x2.3 GHz Kryo 470 Gold + 6x1.8 GHz Kryo 470 Silver), Kamera: Quad kamera 64 MP (Wide), 8 MP (Ultra Wide), 5 MP (Macro), 2 MP (Depth) dengan fitur Night mode, HDR, dan Panorama, kamera depan 16 MP dengan fitur HDR, SIM: Hybrid Dual SIM (Nano-SIM, dual stand-by), Baterai: Non-removable Li-Po 5020 mAh, Fast Charging 33W', 150000.00, 25, 'A', '2023-07-16 20:37:07', '2023-07-16 20:37:07'),
(4, 'MPooFfRhBA7Qhtq', 'Google Pixel 5 - Just Black 8/128 GB', 'Ukuran layar: 6 inci, OLED, 1080 x 2340 piksel, 432 ppi, Memori: RAM 8 GB, ROM 128 GB, Sistem operasi: Android 11, CPU: Qualcomm Snapdragon 765G Octa-core (1x2.4 GHz Kryo 475 Prime + 1x2.2 GHz Kryo 475 Gold + 6x1.8 GHz Kryo 475 Silver), Kamera: Dual kamera 12.2 MP (Wide), 16 MP (Ultra Wide) dengan fitur Night Sight, Portrait Light, dan HDR+, kamera depan 8 MP dengan fitur Night Sight dan HDR+, SIM: Nano-SIM dan eSIM, Baterai: Non-removable Li-Po 4080 mAh, Fast Charging 18W, Wireless Charging', 180000.00, 10, 'A', '2023-07-16 20:37:07', '2023-07-16 20:37:07'),
(5, 'SvfVyjYzjbBtHfu', 'OnePlus 9 Pro - Morning Mist 12/256 GB', 'Ukuran layar: 6.7 inci, Fluid AMOLED, 1440 x 3216 piksel, 525 ppi, 120Hz, Memori: RAM 12 GB (LPDDR5), ROM 256 GB (UFS 3.1), Sistem operasi: OxygenOS based on Android 11, CPU: Qualcomm Snapdragon 888 Octa-core (1x2.84 GHz Kryo 680 + 3x2.42 GHz Kryo 680 + 4x1.80 GHz Kryo 680), Kamera: Quad kamera 48 MP (Wide), 50 MP (Ultra Wide), 8 MP (Telefoto), 2 MP (Monochrome) dengan fitur Hasselblad Camera for Mobile, Nightscape, Super Macro, dan banyak lagi, kamera depan 16 MP dengan fitur Nightscape, SIM: Dual SIM (Nano-SIM, dual stand-by), Baterai: Non-removable Li-Po 4500 mAh, Warp Charge 65T, 50W Wireless Charging', 170000.00, 15, 'A', '2023-07-16 20:37:07', '2023-07-16 20:37:07');

-- --------------------------------------------------------

--
-- Table structure for table `item_gift_images`
--

CREATE TABLE `item_gift_images` (
  `item_gift_id` bigint UNSIGNED NOT NULL,
  `item_gift_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `item_gift_images`
--

INSERT INTO `item_gift_images` (`item_gift_id`, `item_gift_image`, `created_at`, `updated_at`) VALUES
(1, 'image.png', '2023-07-16 20:37:07', '2023-07-16 20:37:07'),
(2, 'image.png', '2023-07-16 20:37:07', '2023-07-16 20:37:07'),
(3, 'image.png', '2023-07-16 20:37:07', '2023-07-16 20:37:07'),
(4, 'image.png', '2023-07-16 20:37:07', '2023-07-16 20:37:07'),
(5, 'image.png', '2023-07-16 20:37:07', '2023-07-16 20:37:07');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1),
(9, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(10, '2023_07_14_023241_create_permission_tables', 1),
(11, '2023_07_14_025924_add_username_to_users_table', 1),
(12, '2023_07_14_030152_create_item_gifts_table', 1),
(13, '2023_07_14_030707_create_item_gift_images_table', 1),
(14, '2023_07_14_031728_create_redeems_table', 1),
(15, '2023_07_14_032047_create_redeem_item_gifts_table', 1),
(16, '2023_07_14_032416_create_reviews_table', 1),
(17, '2023_07_14_033001_create_wishlists_table', 1),
(18, '2023_07_16_085950_update_item_gift_image_url_to_item_gift_images_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Http\\Models\\User', 1),
(2, 'App\\Http\\Models\\User', 2);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'edit users', 'api', '2023-07-16 20:36:59', '2023-07-16 20:36:59'),
(2, 'delete users', 'api', '2023-07-16 20:37:01', '2023-07-16 20:37:01'),
(3, 'create users', 'api', '2023-07-16 20:37:02', '2023-07-16 20:37:02'),
(4, 'view users', 'api', '2023-07-16 20:37:02', '2023-07-16 20:37:02'),
(5, 'edit item gifts', 'api', '2023-07-16 20:37:02', '2023-07-16 20:37:02'),
(6, 'delete item gifts', 'api', '2023-07-16 20:37:02', '2023-07-16 20:37:02'),
(7, 'create item gifts', 'api', '2023-07-16 20:37:03', '2023-07-16 20:37:03'),
(8, 'view item gifts', 'api', '2023-07-16 20:37:03', '2023-07-16 20:37:03');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `redeems`
--

CREATE TABLE `redeems` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `redeem_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_point` double(12,2) NOT NULL,
  `redeem_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `redeem_item_gifts`
--

CREATE TABLE `redeem_item_gifts` (
  `redeem_id` bigint UNSIGNED NOT NULL,
  `item_gift_id` bigint UNSIGNED NOT NULL,
  `redeem_quantity` int NOT NULL,
  `redeem_point` double(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `item_gift_id` bigint UNSIGNED NOT NULL,
  `review_text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `review_rating` decimal(2,1) NOT NULL,
  `review_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'api', '2023-07-16 20:37:03', '2023-07-16 20:37:03'),
(2, 'customer', 'api', '2023-07-16 20:37:05', '2023-07-16 20:37:05');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(8, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'siadmin', 'admin@mail.com', NULL, '$2y$10$Zvj0VBjdsv7lxuP.9JDZGuJfP4sNHqJlU4E.RsM7t7CuIAbYa1Bqu', NULL, '2023-07-16 20:36:57', '2023-07-16 20:36:57'),
(2, 'Eko', 'sieko', 'eko@mail.com', NULL, '$2y$10$2J86P38pwBmUOcVCvF5x.OKcdJf.rLw/GO.Zez7xZ7EPXqIZ9ntWC', NULL, '2023-07-16 20:36:57', '2023-07-16 20:36:57');

-- --------------------------------------------------------

--
-- Table structure for table `wishlists`
--

CREATE TABLE `wishlists` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `item_gift_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `item_gifts`
--
ALTER TABLE `item_gifts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_gifts_item_gift_code_unique` (`item_gift_code`),
  ADD KEY `index_item_gifts` (`item_gift_code`,`item_gift_name`);

--
-- Indexes for table `item_gift_images`
--
ALTER TABLE `item_gift_images`
  ADD KEY `index_item_gift_images` (`item_gift_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `redeems`
--
ALTER TABLE `redeems`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `redeems_redeem_code_unique` (`redeem_code`),
  ADD KEY `redeems_user_id_foreign` (`user_id`),
  ADD KEY `index_redeems` (`redeem_code`,`redeem_date`);

--
-- Indexes for table `redeem_item_gifts`
--
ALTER TABLE `redeem_item_gifts`
  ADD KEY `redeem_item_gifts_item_gift_id_foreign` (`item_gift_id`),
  ADD KEY `index_redeem_item_gifts` (`redeem_id`,`item_gift_id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `reviews_item_gift_id_foreign` (`item_gift_id`),
  ADD KEY `index_reviews` (`user_id`,`item_gift_id`,`review_date`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD UNIQUE KEY `users_username_unique` (`username`);

--
-- Indexes for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wishlists_item_gift_id_foreign` (`item_gift_id`),
  ADD KEY `index_wishlists` (`user_id`,`item_gift_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `item_gifts`
--
ALTER TABLE `item_gifts`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `redeems`
--
ALTER TABLE `redeems`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wishlists`
--
ALTER TABLE `wishlists`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `item_gift_images`
--
ALTER TABLE `item_gift_images`
  ADD CONSTRAINT `item_gift_images_item_gift_id_foreign` FOREIGN KEY (`item_gift_id`) REFERENCES `item_gifts` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `redeems`
--
ALTER TABLE `redeems`
  ADD CONSTRAINT `redeems_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `redeem_item_gifts`
--
ALTER TABLE `redeem_item_gifts`
  ADD CONSTRAINT `redeem_item_gifts_item_gift_id_foreign` FOREIGN KEY (`item_gift_id`) REFERENCES `item_gifts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `redeem_item_gifts_redeem_id_foreign` FOREIGN KEY (`redeem_id`) REFERENCES `redeems` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_item_gift_id_foreign` FOREIGN KEY (`item_gift_id`) REFERENCES `item_gifts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wishlists`
--
ALTER TABLE `wishlists`
  ADD CONSTRAINT `wishlists_item_gift_id_foreign` FOREIGN KEY (`item_gift_id`) REFERENCES `item_gifts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `wishlists_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
