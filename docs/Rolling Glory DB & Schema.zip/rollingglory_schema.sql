CREATE TABLE `users` (
  `id` integer PRIMARY KEY NOT NULL,
  `name` varchar(100),
  `username` varchar(20) UNIQUE,
  `email` varchar(150) UNIQUE,
  `password` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp
);

CREATE TABLE `item_gifts` (
  `id` integer PRIMARY KEY NOT NULL,
  `item_gift_code` varchar(15) UNIQUE,
  `item_gift_name` varchar(150),
  `item_gift_description` text,
  `item_gift_point` double(10, 2),
  `item_gift_quantity` integer,
  `item_gift_status` ENUM ('A', 'O') COMMENT 'The value is : Available (A), Out Of Stock (O)',
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp
);

CREATE TABLE `item_gift_images` (
  `item_gift_id` integer,
  `item_gift_image` varchar(255),
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp
);

CREATE TABLE `redeems` (
  `id` integer PRIMARY KEY NOT NULL,
  `user_id` integer,
  `redeem_code` varchar(20) UNIQUE,
  `total_point` double(12, 2),
  `redeem_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp
);

CREATE TABLE `redeem_item_gifts` (
  `redeem_id` integer,
  `item_gift_id` integer,
  `redeem_quantity` integer,
  `redeem_point` double(10, 2)
);

CREATE TABLE `reviews` (
  `id` integer PRIMARY KEY NOT NULL,
  `user_id` integer,
  `item_gift_id` integer,
  `review_text` text NOT NULL,
  `review_rating` decimal(2, 1),
  `review_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp
);

CREATE TABLE `wishlists` (
  `id` integer PRIMARY KEY NOT NULL,
  `user_id` integer,
  `item_gift_id` integer,
  `created_at` timestamp NOT NULL DEFAULT (now()),
  `updated_at` timestamp
);

CREATE INDEX `item_gifts_index_0` ON `item_gifts` (`item_gift_code`);

CREATE INDEX `item_gifts_index_1` ON `item_gifts` (`item_gift_name`);

CREATE INDEX `item_gift_images_index_2` ON `item_gift_images` (`item_gift_id`);

CREATE INDEX `redeems_index_3` ON `redeems` (`user_id`);

CREATE INDEX `redeems_index_4` ON `redeems` (`redeem_code`);

CREATE INDEX `redeems_index_5` ON `redeems` (`redeem_date`);

CREATE INDEX `redeem_item_gifts_index_6` ON `redeem_item_gifts` (`redeem_id`);

CREATE INDEX `redeem_item_gifts_index_7` ON `redeem_item_gifts` (`item_gift_id`);

CREATE INDEX `reviews_index_8` ON `reviews` (`user_id`);

CREATE INDEX `reviews_index_9` ON `reviews` (`item_gift_id`);

CREATE INDEX `reviews_index_10` ON `reviews` (`review_date`);

CREATE INDEX `wishlists_index_11` ON `wishlists` (`user_id`);

CREATE INDEX `wishlists_index_12` ON `wishlists` (`item_gift_id`);

ALTER TABLE `redeems` ADD FOREIGN KEY (`id`) REFERENCES `redeem_item_gifts` (`redeem_id`);

ALTER TABLE `item_gifts` ADD FOREIGN KEY (`id`) REFERENCES `redeem_item_gifts` (`item_gift_id`);

ALTER TABLE `item_gift_images` ADD FOREIGN KEY (`item_gift_id`) REFERENCES `item_gifts` (`id`);

ALTER TABLE `redeems` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `reviews` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `reviews` ADD FOREIGN KEY (`item_gift_id`) REFERENCES `item_gifts` (`id`);

ALTER TABLE `wishlists` ADD FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `wishlists` ADD FOREIGN KEY (`item_gift_id`) REFERENCES `item_gifts` (`id`);
